<template>
  <!-- 图表容器：宽高由父容器控制 -->
  <div ref="chartRef" class="echart-container"></div>
</template>

<script setup>
// 通用 ECharts 图表组件
// - 根据 chartType + chartData + chartConfig 渲染不同图表
// - 自动处理初始化、更新、resize、自销毁

import { ref, onMounted, onBeforeUnmount, watch } from 'vue'
import { initEchartsInstance } from '@/utils/echarts'
import { throttle } from '@/utils/performance'

const props = defineProps({
  chartType: {
    type: String, // line / bar / pie / ring / map
    required: true
  },
  chartData: {
    type: Object,
    default: () => ({})
  },
  chartConfig: {
    type: Object,
    default: () => ({})
  }
})

const chartRef = ref(null)
let chartInstance = null

// 初始化图表
const initChart = () => {
  if (!chartRef.value) return
  chartInstance = initEchartsInstance(chartRef.value)
  updateChart()
}

// 根据类型构建 option 并更新图表
const updateChart = () => {
  if (!chartInstance) return
  if (!props.chartData || Object.keys(props.chartData).length === 0) return

  let option = {}

  if (props.chartType === 'line') {
    option = buildLineOption(props.chartData, props.chartConfig)
  } else if (props.chartType === 'bar') {
    option = buildBarOption(props.chartData, props.chartConfig)
  } else if (props.chartType === 'pie' || props.chartType === 'ring') {
    option = buildPieOption(props.chartData, props.chartConfig)
  } else if (props.chartType === 'map') {
    option = buildMapOption(props.chartData, props.chartConfig)
  }

  chartInstance.setOption(option, true)
  chartInstance.resize()
}

// 折线图配置（用户访问趋势 / 销售趋势）
const buildLineOption = (data, config) => ({
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'axis'
  },
  legend: {
    textStyle: { color: '#e5e7eb' }
  },
  grid: {
    left: '8%',
    right: '5%',
    top: '10%',
    bottom: '12%'
  },
  xAxis: {
    type: 'category',
    boundaryGap: false,
    data: data.xAxis || [],
    axisLine: { lineStyle: { color: '#4b5563' } },
    axisLabel: { color: '#9ca3af' }
  },
  yAxis: {
    type: 'value',
    axisLine: { lineStyle: { color: '#4b5563' } },
    axisLabel: { color: '#9ca3af' },
    splitLine: { lineStyle: { color: '#1f2933' } }
  },
  series: (data.series || []).map((s) => ({
    type: 'line',
    smooth: true,
    showSymbol: false,
    ...s
  })),
  ...config
})

// 柱状图配置（商品分类销量）
const buildBarOption = (data, config) => ({
  backgroundColor: 'transparent',
  tooltip: { trigger: 'axis' },
  grid: { left: '8%', right: '5%', top: '10%', bottom: '12%' },
  xAxis: {
    type: 'category',
    data: data.xAxis || [],
    axisLine: { lineStyle: { color: '#4b5563' } },
    axisLabel: { color: '#9ca3af' }
  },
  yAxis: {
    type: 'value',
    axisLine: { lineStyle: { color: '#4b5563' } },
    axisLabel: { color: '#9ca3af' },
    splitLine: { lineStyle: { color: '#1f2933' } }
  },
  series: [
    {
      type: 'bar',
      data: data.values || [],
      itemStyle: {
        borderRadius: [4, 4, 0, 0],
        color: {
          type: 'linear',
          x: 0,
          y: 0,
          x2: 0,
          y2: 1,
          colorStops: [
            { offset: 0, color: '#3b82f6' },
            { offset: 1, color: '#1e293b' }
          ]
        }
      }
    }
  ],
  ...config
})

// 饼图/环形图配置（订单来源占比）
const buildPieOption = (data, config) => ({
  backgroundColor: 'transparent',
  tooltip: { trigger: 'item' },
  legend: {
    bottom: 5,
    textStyle: { color: '#e5e7eb', fontSize: 10 },
    itemWidth: 8,
    itemHeight: 8,
    itemGap: 10,
    padding: [0, 0, 10, 0]
  },
  series: [
    {
      name: data.name || '',
      type: 'pie',
      radius: props.chartType === 'ring' ? ['45%', '70%'] : '55%',
      center: ['50%', '45%'],
      data: data.values || [],
      label: {
        color: '#e5e7eb',
        fontSize: 9,
        formatter: '{b}: {d}%',
        position: 'outside',
        align: 'center',
        verticalAlign: 'middle',
        distance: 15,
        show: (params) => {
          // 只显示占比大于5%的数据标签，避免拥挤
          return params.percent > 5
        }
      },
      labelLine: {
        length: 10,
        length2: 10,
        lineStyle: {
          color: '#9ca3af',
          width: 1
        }
      }
    }
  ],
  ...config
})

// 地图配置（各地区订单分布）- 区域热力填充 + 顶部数值标签
const buildMapOption = (data, config) => {
  const regions = data.values || []
  const maxVal = Math.max(...regions.map((d) => d.value || 0), 1)

  // 省份名称映射（匹配 GeoJSON 中的名称格式）
  const nameMap = {
    '北京': '北京市',
    '上海': '上海市',
    '广东': '广东省',
    '浙江': '浙江省',
    '江苏': '江苏省',
    '四川': '四川省',
    '山东': '山东省',
    '湖北': '湖北省',
    '福建': '福建省',
    '河南': '河南省',
    '湖南': '湖南省',
    '安徽': '安徽省',
    '河北': '河北省',
    '陕西': '陕西省',
    '重庆': '重庆市',
    '辽宁': '辽宁省',
    '天津': '天津市',
    '江西': '江西省',
    '广西': '广西壮族自治区',
    '云南': '云南省',
    '贵州': '贵州省',
    '甘肃': '甘肃省',
    '海南': '海南省',
    '内蒙古': '内蒙古自治区',
    '新疆': '新疆维吾尔自治区',
    '西藏': '西藏自治区',
    '宁夏': '宁夏回族自治区',
    '青海': '青海省',
    '黑龙江': '黑龙江省',
    '吉林': '吉林省',
    '山西': '山西省'
  }

  // 转换数据名称以匹配地图
  const mappedRegions = regions.map(item => ({
    name: nameMap[item.name] || item.name,
    value: item.value
  }))

  return {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'item',
      backgroundColor: 'rgba(15, 23, 42, 0.9)',
      borderColor: '#3b82f6',
      textStyle: { color: '#e5e7eb' },
      formatter: (params) => {
        if (params.value) {
          return `<div style="font-weight:bold;margin-bottom:4px;">${params.name}</div>
                  <div>订单量：<span style="color:#3b82f6;font-weight:bold;">${params.value.toLocaleString()}</span></div>
                  <div>占比：<span style="color:#22c55e;">${((params.value / maxVal) * 100).toFixed(1)}%</span></div>`
        }
        return params.name
      }
    },
    // 视觉映射 - 控制省份填充颜色
    visualMap: {
      min: 0,
      max: maxVal,
      left: '3%',
      bottom: '5%',
      text: ['高', '低'],
      textStyle: { color: '#9ca3af' },
      calculable: true,
      inRange: {
        color: ['#0f172a', '#1e3a5f', '#2563eb', '#3b82f6', '#60a5fa', '#93c5fd']
      }
    },
    series: [
      {
        type: 'map',
        map: 'china',
        roam: true,
        zoom: 1.15,
        center: [105, 38],
        layoutCenter: ['50%', '52%'],
        layoutSize: '98%',
        // 省份填充数据
        data: mappedRegions,
        label: {
          show: true,
          fontSize: 11,
          color: '#e5e7eb',
          formatter: (params) => {
            // 只显示高价值省份，避免标签过多重叠
            const topProvinces = ['广东', '上海', '北京', '浙江', '江苏', '四川', '山东', '湖北']
            const shortName = params.name.replace(/省|市|自治区|壮族|回族|维吾尔/g, '')
            if (params.value && topProvinces.includes(shortName)) {
              return `{name|${shortName}}`
            }
            return ''
          },
          rich: {
            name: {
              fontSize: 11,
              color: '#fff',
              fontWeight: 'bold',
              textShadowColor: 'rgba(0,0,0,0.8)',
              textShadowBlur: 3
            }
          }
        },
        itemStyle: {
          areaColor: '#0f172a',
          borderColor: '#1e3a5f',
          borderWidth: 1
        },
        emphasis: {
          label: {
            show: true,
            fontSize: 12,
            fontWeight: 'bold',
            color: '#fff'
          },
          itemStyle: {
            areaColor: '#f59e0b',
            shadowBlur: 20,
            shadowColor: 'rgba(245, 158, 11, 0.5)'
          }
        },
        select: {
          itemStyle: {
            areaColor: '#f59e0b'
          }
        }
      }
    ],
    ...config
  }
}

// resize 事件节流处理
const handleResize = throttle(() => {
  if (chartInstance) {
    chartInstance.resize()
  }
}, 200)

onMounted(() => {
  initChart()
  window.addEventListener('resize', handleResize)
})

// 监听数据变化，自动更新图表
watch(
  () => props.chartData,
  () => {
    updateChart()
  },
  { deep: true }
)

onBeforeUnmount(() => {
  window.removeEventListener('resize', handleResize)
  if (chartInstance) {
    chartInstance.dispose()
    chartInstance = null
  }
})
</script>

<style scoped>
.echart-container {
  width: 100%;
  height: 100%;
}
</style>

