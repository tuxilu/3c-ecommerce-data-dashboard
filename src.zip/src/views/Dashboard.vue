<template>
  <div class="dashboard">
    <!-- 顶部：标题 + 时间筛选 + 全屏 -->
    <header class="dashboard-header">
      <div>
        <h1 class="title">3C 数码电商运营数据可视化大屏</h1>
        <p class="subtitle">实时监控销售、订单、流量、区域与品类表现</p>
      </div>
      <div class="header-right">
        <div class="time-filters">
          <button
            v-for="item in timeOptions"
            :key="item.value"
            :class="['time-btn', { active: timeRange === item.value }]"
            @click="handleTimeChange(item.value)"
          >
            {{ item.label }}
          </button>
        </div>
        <button class="fullscreen-btn" @click="toggleFullScreen">
          {{ isFullScreen ? '退出全屏' : '全屏模式' }}
        </button>
      </div>
    </header>

    <!-- 主体 Grid 布局 -->
    <main class="dashboard-grid">
      <!-- 左上：核心 KPI -->
      <section class="card kpi-card">
        <div class="kpi-item">
          <div class="kpi-label">今日销售额（元）</div>
          <div class="kpi-value">{{ salesData?.today?.toLocaleString?.() || '-' }}</div>
          <div class="kpi-sub">同比昨日 {{ salesYoY }}%</div>
        </div>
        <div class="kpi-item">
          <div class="kpi-label">今日订单量（单）</div>
          <div class="kpi-value">{{ orderData?.today || '-' }}</div>
          <div class="kpi-sub">过去7天订单趋势如右图</div>
        </div>
      </section>

      <!-- 中上：销售趋势折线图 -->
      <section class="card chart-card chart-sales">
        <h2 class="card-title">近7天销售趋势</h2>
        <EchartsChart
          v-if="salesData"
          chart-type="line"
          :chart-data="salesLineData"
        />
      </section>

      <!-- 右上：订单来源占比环形图 -->
      <section class="card chart-card chart-source">
        <h2 class="card-title">订单来源占比</h2>
        <EchartsChart
          v-if="sourceData.length"
          chart-type="ring"
          :chart-data="sourcePieData"
        />
      </section>

      <!-- 左下：商品分类销量柱状图 -->
      <section class="card chart-card chart-category">
        <h2 class="card-title">商品分类销量</h2>
        <EchartsChart
          v-if="categoryData.length"
          chart-type="bar"
          :chart-data="categoryBarData"
        />
      </section>

      <!-- 中下：用户访问趋势折线图 -->
      <section class="card chart-card chart-trend">
        <h2 class="card-title">用户访问趋势（PV/UV）</h2>
        <EchartsChart
          v-if="trendData"
          chart-type="line"
          :chart-data="trendLineData"
        />
      </section>

      <!-- 右下：区域订单分布地图 -->
      <section class="card chart-card chart-region">
        <h2 class="card-title">各地区订单分布</h2>
        <EchartsChart
          v-if="regionData.length"
          chart-type="map"
          :chart-data="regionMapData"
        />
      </section>
    </main>
  </div>
</template>

<script setup>
import { onMounted, computed } from 'vue'
import { useDataStore } from '@/stores/dataStore'
import { storeToRefs } from 'pinia'
import { debounce } from '@/utils/performance'
import EchartsChart from '@/components/EchartsChart.vue'

const dataStore = useDataStore()

// 从仓库中解构出响应式数据与 getter
const {
  salesData,
  orderData,
  categoryData,
  regionData,
  trendData,
  sourceData,
  timeRange,
  isFullScreen,
  salesYoY
} = storeToRefs(dataStore)

const timeOptions = [
  { label: '今日', value: 'today' },
  { label: '近7天', value: '7d' },
  { label: '近30天', value: '30d' }
]

// 时间筛选切换，使用防抖避免过快点击
const handleTimeChange = debounce((val) => {
  dataStore.setTimeRange(val)
}, 200)

// 全屏切换
const toggleFullScreen = async () => {
  if (!document.fullscreenElement) {
    await document.documentElement.requestFullscreen()
    dataStore.setFullScreen(true)
  } else {
    await document.exitFullscreen()
    dataStore.setFullScreen(false)
  }
}

// 计算图表所需的数据结构，适配通用组件
const salesLineData = computed(() => {
  if (!salesData.value) return {}
  return {
    xAxis: salesData.value.timeAxis || [],
    series: [
      {
        name: '销售额',
        data: salesData.value.last7Days || [],
        areaStyle: {},
        emphasis: { focus: 'series' }
      }
    ]
  }
})

const sourcePieData = computed(() => ({
  name: '来源占比',
  values: sourceData.value
}))

const categoryBarData = computed(() => ({
  xAxis: categoryData.value.map((c) => c.name),
  values: categoryData.value.map((c) => c.value)
}))

const trendLineData = computed(() => {
  if (!trendData.value) return {}
  return {
    xAxis: trendData.value.timeAxis,
    series: [
      { name: 'PV', data: trendData.value.pv },
      { name: 'UV', data: trendData.value.uv }
    ]
  }
})

const regionMapData = computed(() => ({
  values: regionData.value
}))

onMounted(() => {
  // 首次进入大屏时加载一次数据
  dataStore.fetchAllData()

  // 模拟定时刷新，体现实时监控场景
  const timer = setInterval(() => {
    dataStore.fetchAllData()
  }, 5000)

  window.addEventListener('beforeunload', () => clearInterval(timer))
})
</script>

