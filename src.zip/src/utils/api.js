// src/utils/api.js
// 对外暴露的获取大屏数据的函数

import request from './request'

// 获取整套大屏数据（销售、订单、分类、区域、趋势等）
export function getDashboardData() {
  // 直接读取 public/mock/dashboard.json
  // 真实接后端时，改为 request.get('/api/dashboard') 即可
  return request.get('/mock/dashboard.json')
}

// 示例：按模块单独获取（当前仍从同一个 JSON 中拆）
export function getSalesData() {
  return request.get('/mock/dashboard.json').then((data) => data.salesData)
}

export function getOrderData() {
  return request.get('/mock/dashboard.json').then((data) => data.orderData)
}

