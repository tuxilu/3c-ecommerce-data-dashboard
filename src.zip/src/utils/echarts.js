// src/utils/echarts.js
// 使用完整 ECharts 构建，简化地图注册兼容性问题

import * as echarts from 'echarts'
import chinaJson from '@/assets/china.json'

// 注册中国地图（用于地区订单分布）
echarts.registerMap('china', chinaJson)

export function initEchartsInstance(dom) {
  return echarts.init(dom)
}

export default echarts

