// src/utils/performance.js
// 性能相关工具函数：防抖与节流

/**
 * 防抖：在事件停止一段时间后再执行
 * 适用场景：输入搜索、窗口 resize 结束后计算布局等
 */
export function debounce(fn, delay = 300) {
  let timer = null
  return function (...args) {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => {
      fn.apply(this, args)
    }, delay)
  }
}

/**
 * 节流：在指定间隔内只触发一次
 * 适用场景：滚动监听、窗口 resize、频繁触发的图表重绘
 */
export function throttle(fn, interval = 200) {
  let lastTime = 0
  return function (...args) {
    const now = Date.now()
    if (now - lastTime > interval) {
      lastTime = now
      fn.apply(this, args)
    }
  }
}

