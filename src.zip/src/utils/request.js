// src/utils/request.js
// Axios 请求封装：拦截器 + 统一错误处理

import axios from 'axios'

// 简单的全局 loading 计数（可与 UI 框架结合）
let loadingCount = 0

// 创建 axios 实例
const service = axios.create({
  baseURL: '/', // 统一使用相对路径，方便本地 mock 与后端切换
  timeout: 10000
})

// 请求拦截器
service.interceptors.request.use(
  (config) => {
    // 示例：附加 token（如需登录，可从本地存储获取）
    const token = localStorage.getItem('TOKEN')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }

    loadingCount++
    // 这里可以触发全局 loading 状态
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// 响应拦截器
service.interceptors.response.use(
  (response) => {
    loadingCount--
    const res = response.data

    // 如果后端采用 { code, data, msg } 结构，可在此统一处理
    if (res && typeof res === 'object' && 'code' in res) {
      if (res.code !== 0) {
        console.error('接口错误：', res.msg || '未知错误')
        return Promise.reject(new Error(res.msg || '接口错误'))
      }
      return res.data
    }

    // public/mock 下的 JSON 直接返回
    return res
  },
  (error) => {
    loadingCount--
    if (error.response) {
      console.error('HTTP错误：', error.response.status, error.response.statusText)
    } else if (error.request) {
      console.error('网络错误或服务器无响应')
    } else {
      console.error('Axios配置错误：', error.message)
    }
    return Promise.reject(error)
  }
)

export default service

