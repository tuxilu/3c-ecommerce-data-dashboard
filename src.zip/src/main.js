import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import './assets/styles/index.scss'

const app = createApp(App)

// 注册 Pinia
const pinia = createPinia()
app.use(pinia)

app.mount('#app')
