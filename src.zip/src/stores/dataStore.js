// src/stores/dataStore.js
// 大屏数据的 Pinia 仓库：负责加载与管理运营指标 + 筛选条件

import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { getDashboardData } from '@/utils/api'

export const useDataStore = defineStore('dataStore', () => {
  // ========== state ==========

  const salesData = ref(null)     // 销售额相关
  const orderData = ref(null)     // 订单量相关
  const categoryData = ref([])    // 分类销量
  const regionData = ref([])      // 地区订单分布
  const trendData = ref(null)     // 用户访问 PV/UV
  const sourceData = ref([])      // 订单来源占比

  // 筛选条件：时间范围 today / 7d / 30d
  const timeRange = ref('7d')

  // 大屏是否全屏
  const isFullScreen = ref(false)

  // 加载状态
  const loading = ref(false)

  // ========== actions ==========

  // 从 mock 接口加载整套数据
  const fetchAllData = async () => {
    loading.value = true
    try {
      // 首次加载时根据当前时间范围生成数据
      generateMockDataByRange(timeRange.value)
    } catch (error) {
      console.error('加载大屏数据失败：', error)
    } finally {
      loading.value = false
    }
  }

  // 切换时间范围 - 根据时间范围生成对应数据
  const setTimeRange = (range) => {
    timeRange.value = range
    // 根据时间范围生成不同的模拟数据
    generateMockDataByRange(range)
  }

  // 根据时间范围生成模拟数据
  const generateMockDataByRange = (range) => {
    const multiplier = range === 'today' ? 0.3 : range === '30d' ? 2.5 : 1
    
    // 生成销售数据
    const baseSales = [82000, 91000, 100000, 115000, 120000, 123000, 128500]
    salesData.value = {
      today: Math.floor(128500 * multiplier),
      yesterday: Math.floor(110300 * multiplier),
      last7Days: baseSales.map(v => Math.floor(v * multiplier)),
      timeAxis: range === 'today' 
        ? ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00', '24:00']
        : range === '30d'
        ? ['第1周', '第2周', '第3周', '第4周', '第5周', '第6周', '第7周']
        : ['周一', '周二', '周三', '周四', '周五', '周六', '今天']
    }

    // 生成订单数据
    orderData.value = {
      today: Math.floor(3520 * multiplier),
      yesterday: Math.floor(3010 * multiplier),
      last7Days: [2100, 2500, 2800, 3000, 3100, 3300, 3520].map(v => Math.floor(v * multiplier))
    }

    // 生成分类数据（随机波动）
    const baseCategory = [
      { name: '手机数码', value: 420000 },
      { name: '服饰鞋帽', value: 260000 },
      { name: '家用电器', value: 180000 },
      { name: '美妆个护', value: 120000 },
      { name: '食品饮料', value: 90000 }
    ]
    categoryData.value = baseCategory.map(item => ({
      ...item,
      value: Math.floor(item.value * multiplier * (0.8 + Math.random() * 0.4))
    }))

    // 生成地区数据（随机波动）
    const baseRegion = [
      { name: '北京', value: 120000 },
      { name: '上海', value: 150000 },
      { name: '广东', value: 175000 },
      { name: '浙江', value: 95000 },
      { name: '江苏', value: 88000 },
      { name: '四川', value: 72000 },
      { name: '山东', value: 68000 },
      { name: '湖北', value: 55000 },
      { name: '福建', value: 48000 },
      { name: '河南', value: 42000 },
      { name: '湖南', value: 38000 },
      { name: '安徽', value: 32000 },
      { name: '河北', value: 28000 },
      { name: '陕西', value: 25000 },
      { name: '重庆', value: 22000 },
      { name: '辽宁', value: 18000 },
      { name: '天津', value: 15000 },
      { name: '江西', value: 12000 },
      { name: '广西', value: 10000 },
      { name: '云南', value: 8500 }
    ]
    regionData.value = baseRegion.map(item => ({
      ...item,
      value: Math.floor(item.value * multiplier * (0.8 + Math.random() * 0.4))
    }))

    // 生成趋势数据
    const basePV = [12000, 13500, 15000, 18000, 20000, 22000, 25000]
    const baseUV = [6000, 6800, 7200, 8000, 8800, 9200, 10000]
    trendData.value = {
      pv: basePV.map(v => Math.floor(v * multiplier)),
      uv: baseUV.map(v => Math.floor(v * multiplier)),
      timeAxis: range === 'today'
        ? ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00', '24:00']
        : range === '30d'
        ? ['第1周', '第2周', '第3周', '第4周', '第5周', '第6周', '第7周']
        : ['周一', '周二', '周三', '周四', '周五', '周六', '今天']
    }

    // 生成来源数据（随机波动）
    const baseSource = [
      { name: '搜索', value: 45 },
      { name: '直接访问', value: 20 },
      { name: '社交平台', value: 15 },
      { name: '广告投放', value: 12 },
      { name: '其他', value: 8 }
    ]
    sourceData.value = baseSource.map(item => ({
      ...item,
      value: Math.floor(item.value * (0.7 + Math.random() * 0.6))
    }))
  }

  // 更新全屏状态
  const setFullScreen = (val) => {
    isFullScreen.value = val
  }

  // ========== getters ==========

  // 销售额同比昨日增长率（%）
  const salesYoY = computed(() => {
    if (!salesData.value) return 0
    const today = salesData.value.today
    const yesterday = salesData.value.yesterday || 1
    return (((today - yesterday) / yesterday) * 100).toFixed(1)
  })

  return {
    // state
    salesData,
    orderData,
    categoryData,
    regionData,
    trendData,
    sourceData,
    timeRange,
    isFullScreen,
    loading,
    // actions
    fetchAllData,
    setTimeRange,
    setFullScreen,
    // getters
    salesYoY
  }
})

